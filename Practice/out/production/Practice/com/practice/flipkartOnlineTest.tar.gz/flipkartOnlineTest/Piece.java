package com.practice.flipkartOnlineTest;

public interface Piece {
    boolean canMove(Cell postion1, Cell position2,Cell[][] board);
}
