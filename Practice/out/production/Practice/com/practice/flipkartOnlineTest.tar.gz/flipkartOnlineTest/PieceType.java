package com.practice.flipkartOnlineTest;

public enum PieceType {
    ROOK,BISHOP,HORSE,KING,QUEEN,PAWN
}

enum Color{
    WHITE,BLACK
}
